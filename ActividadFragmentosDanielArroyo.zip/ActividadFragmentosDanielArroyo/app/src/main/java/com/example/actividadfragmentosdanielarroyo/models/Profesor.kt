package com.example.actividadfragmentosdanielarroyo.models

data class Profesor (
    val nombre: String = "",
    val apellido: String = ""
)
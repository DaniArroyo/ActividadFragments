package com.example.actividadfragmentosdanielarroyo.models

data class Alumno (
    val id: Int?=0,
    val nombre: String = "",
    val apellido: String = ""
)